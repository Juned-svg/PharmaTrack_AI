import os
from pathlib import Path

# Define project base directory
base_dir = Path("PharmaTrack_AI")

# Step 1: Create Complete Folder Hierarchy
structure = [
    "data/raw", 
    "data/validated", 
    "data/quarantine_logs",
    "src", 
    "logs"
]

print("Creating PharmaTrack AI folder layout...")
for folder in structure:
    (base_dir / folder).mkdir(parents=True, exist_ok=True)

# Step 2: Define Content for Every Single Module (Keeping 100% Claude Logic)
files = {}

# 1. requirements.txt
files["requirements.txt"] = """
pydantic>=2.0.0
pandas>=2.0.0
numpy>=1.24.0
scikit-learn>=1.3.0
""".strip()

# 2. src/__init__.py
files["src/__init__.py"] = """
from .parser import LogParser
from .validator import LogValidator, LogRecord
from .anomaly_detector import AnomalyDetector

__all__ = ["LogParser", "LogValidator", "LogRecord", "AnomalyDetector"]
__version__ = "1.0.0"
""".strip()

# 3. src/parser.py
files["src/parser.py"] = """
import re
import logging
from pathlib import Path
from typing import Optional, Generator
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

@dataclass
class ParsedLogEntry:
    timestamp: str
    instrument_id: str
    parameter_type: str
    value: float
    status_code: str
    raw_line: str
    line_number: int

@dataclass
class ParseFailure:
    raw_line: str
    line_number: int
    error_reason: str

@dataclass
class ParseStatistics:
    total_lines: int = 0
    successful_parses: int = 0
    failed_parses: int = 0
    empty_lines: int = 0
    failures: list[ParseFailure] = field(default_factory=list)

class LogParser:
    TIMESTAMP_PATTERN: str = r"(\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2})"
    INSTRUMENT_ID_PATTERN: str = r"(INST-[A-Z0-9]{3})"
    PARAMETER_TYPE_PATTERN: str = r"(TEMP|PRESS|FLOW)"
    VALUE_PATTERN: str = r"(-?\\d+\\.?\\d*)"
    STATUS_CODE_PATTERN: str = r"(OK|WARN|CRITICAL)"
    
    def __init__(self, delimiter: str = r"\\s*\\|\\s*") -> None:
        self._delimiter = delimiter
        self._compiled_pattern = self._build_master_pattern()
        self._statistics = ParseStatistics()
        
    def _build_master_pattern(self) -> re.Pattern[str]:
        pattern_parts = [
            f"^\\s*{self.TIMESTAMP_PATTERN}",
            self.INSTRUMENT_ID_PATTERN,
            self.PARAMETER_TYPE_PATTERN,
            self.VALUE_PATTERN,
            f"{self.STATUS_CODE_PATTERN}\\s*$"
        ]
        master_pattern = self._delimiter.join(pattern_parts)
        return re.compile(master_pattern, re.IGNORECASE)
        
    def _parse_single_line(self, line: str, line_number: int) -> Optional[ParsedLogEntry]:
        stripped_line = line.strip()
        if not stripped_line or stripped_line.startswith("#"):
            self._statistics.empty_lines += 1
            return None
            
        match = self._compiled_pattern.match(stripped_line)
        if match is None:
            failure = ParseFailure(raw_line=stripped_line, line_number=line_number, error_reason="Regex pattern match failed")
            self._statistics.failures.append(failure)
            self._statistics.failed_parses += 1
            return None
            
        try:
            entry = ParsedLogEntry(
                timestamp=match.group(1).strip(),
                instrument_id=match.group(2).strip().upper(),
                parameter_type=match.group(3).strip().upper(),
                value=float(match.group(4).strip()),
                status_code=match.group(5).strip().upper(),
                raw_line=stripped_line,
                line_number=line_number
            )
            self._statistics.successful_parses += 1
            return entry
        except Exception as exc:
            failure = ParseFailure(raw_line=stripped_line, line_number=line_number, error_reason=str(exc))
            self._statistics.failures.append(failure)
            self._statistics.failed_parses += 1
            return None

    def parse_file(self, file_path: Path) -> Generator[ParsedLogEntry, None, None]:
        self._statistics = ParseStatistics()
        if not file_path.exists():
            raise FileNotFoundError(f"Log file does not exist: {file_path}")
        with file_path.open(mode="r", encoding="utf-8") as file_handle:
            for line_number, line in enumerate(file_handle, start=1):
                self._statistics.total_lines += 1
                parsed_entry = self._parse_single_line(line, line_number)
                if parsed_entry is not None:
                    yield parsed_entry

    def parse_file_to_list(self, file_path: Path) -> list[ParsedLogEntry]:
        return list(self.parse_file(file_path))
        
    def get_statistics(self) -> ParseStatistics:
        return self._statistics

    def to_dict(self, entry: ParsedLogEntry) -> dict:
        return {
            "timestamp": entry.timestamp, "instrument_id": entry.instrument_id,
            "parameter_type": entry.parameter_type, "value": entry.value,
            "status_code": entry.status_code, "raw_line": entry.raw_line, "line_number": entry.line_number
        }
""".strip()

# 4. src/validator.py
files["src/validator.py"] = """
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, Any
from enum import Enum
from pydantic import BaseModel, Field, field_validator, model_validator, ValidationError, ConfigDict

logger = logging.getLogger(__name__)

class ParameterType(str, Enum):
    TEMP = "TEMP"
    PRESS = "PRESS"
    FLOW = "FLOW"

class StatusCode(str, Enum):
    OK = "OK"
    WARN = "WARN"
    CRITICAL = "CRITICAL"

class ParameterBoundaries:
    TEMP_MIN, TEMP_MAX = 15.0, 85.0
    PRESS_MIN, PRESS_MAX = 0.5, 5.0
    FLOW_MIN, FLOW_MAX = 0.1, 2.5
    
    @classmethod
    def get_bounds(cls, parameter_type: str) -> tuple[float, float]:
        bounds_map = {"TEMP": (cls.TEMP_MIN, cls.TEMP_MAX), "PRESS": (cls.PRESS_MIN, cls.PRESS_MAX), "FLOW": (cls.FLOW_MIN, cls.FLOW_MAX)}
        return bounds_map[parameter_type]

class LogRecord(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True, extra="forbid")
    timestamp: str
    instrument_id: str = Field(..., pattern=r"^INST-[A-Z0-9]{3}$")
    parameter_type: ParameterType
    value: float
    status_code: StatusCode
    raw_line: Optional[str] = None
    line_number: Optional[int] = None

    @field_validator("timestamp")
    @classmethod
    def validate_timestamp_format(cls, value: str) -> str:
        try:
            datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            raise ValueError(f"Timestamp must be in YYYY-MM-DD HH:MM:SS format, got: {value}")
        return value

    @model_validator(mode="after")
    def validate_value_boundaries(self) -> "LogRecord":
        min_bound, max_bound = ParameterBoundaries.get_bounds(self.parameter_type.value)
        if not (min_bound <= self.value <= max_bound):
            raise ValueError(f"{self.parameter_type.value} value {self.value} outside range [{min_bound}, {max_bound}]")
        return self

    def to_dict(self) -> dict[str, Any]:
        d = self.model_dump()
        d["parameter_type"] = self.parameter_type.value
        d["status_code"] = self.status_code.value
        return d

class LogValidator:
    def __init__(self, quarantine_dir: Path) -> None:
        self._quarantine_dir = quarantine_dir
        self._validated_count = 0
        self._quarantined_count = 0
        self._quarantine_dir.mkdir(parents=True, exist_ok=True)
        
    def validate_record(self, data: dict[str, Any]) -> Optional[LogRecord]:
        try:
            validated = LogRecord(**data)
            self._validated_count += 1
            return validated
        except ValidationError as exc:
            self._quarantined_count += 1
            ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            q_file = self._quarantine_dir / f"quarantine_{ts}.json"
            
            # Pydantic v2 errors standard formats dictionary format me extract karne ke liye
            # .errors() me raw exceptions ko string components me map kar dete hain string formatting se
            serializable_errors = []
            for err in exc.errors():
                serializable_err = err.copy()
                if "ctx" in serializable_err and "error" in serializable_err["ctx"]:
                    # Raw ValueError object ko clean string representation me badlo
                    serializable_err["ctx"]["error"] = str(serializable_err["ctx"]["error"])
                serializable_errors.append(serializable_err)

            with open(q_file, "w") as f:
                json.dump({
                    "original_data": data, 
                    "errors": serializable_errors
                }, f, indent=2)
            return None

    def validate_batch(self, records: list[dict[str, Any]]) -> list[LogRecord]:
        valid_records = []
        for r in records:
            v = self.validate_record(r)
            if v: valid_records.append(v)
        return valid_records

    def get_statistics(self) -> dict[str, int]:
        return {"validated": self._validated_count, "quarantined": self._quarantined_count}
""".strip()

# 5. src/anomaly_detector.py
files["src/anomaly_detector.py"] = """
import logging
from typing import Optional, Any
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger(__name__)

@dataclass
class AnomalyDetectionResult:
    predictions: np.ndarray
    anomaly_scores: np.ndarray
    anomaly_indices: np.ndarray
    normal_indices: np.ndarray
    anomaly_count: int
    normal_count: int
    anomaly_ratio: float
    feature_statistics: dict[str, dict[str, float]] = field(default_factory=dict)

class AnomalyDetector:
    def __init__(self, contamination: float = 0.05, n_estimators: int = 100, random_state: int = 42) -> None:
        self._contamination = contamination
        self._n_estimators = n_estimators
        self._scaler = StandardScaler()
        self._model = IsolationForest(contamination=contamination, n_estimators=n_estimators, random_state=random_state, n_jobs=-1)
        self._dataframe = None
        self._is_fitted = False

    def load_records(self, records: list[dict[str, Any]]) -> pd.DataFrame:
        self._dataframe = pd.DataFrame(records)
        return self._dataframe

    def fit(self, records: Optional[list[dict[str, Any]]] = None) -> "AnomalyDetector":
        if records is not None: self.load_records(records)
        param_encoding = {"TEMP": 0, "PRESS": 1, "FLOW": 2}
        status_encoding = {"OK": 0, "WARN": 1, "CRITICAL": 2}
        
        df = self._dataframe.copy()
        df["param_encoded"] = df["parameter_type"].map(param_encoding)
        df["status_encoded"] = df["status_code"].map(status_encoding)
        
        features = df[["value", "param_encoded", "status_encoded"]].values
        scaled_features = self._scaler.fit_transform(features)
        self._model.fit(scaled_features)
        self._is_fitted = True
        return self

    def detect_anomalies(self) -> AnomalyDetectionResult:
        param_encoding = {"TEMP": 0, "PRESS": 1, "FLOW": 2}
        status_encoding = {"OK": 0, "WARN": 1, "CRITICAL": 2}
        df = self._dataframe.copy()
        df["param_encoded"] = df["parameter_type"].map(param_encoding)
        df["status_encoded"] = df["status_code"].map(status_encoding)
        
        features = df[["value", "param_encoded", "status_encoded"]].values
        scaled_features = self._scaler.transform(features)
        preds = self._model.predict(scaled_features)
        scores = self._model.decision_function(scaled_features)
        
        ano_idx = np.where(preds == -1)[0]
        norm_idx = np.where(preds == 1)[0]
        
        return AnomalyDetectionResult(
            predictions=preds, anomaly_scores=scores, anomaly_indices=ano_idx, normal_indices=norm_idx,
            anomaly_count=len(ano_idx), normal_count=len(norm_idx), anomaly_ratio=len(ano_idx)/len(preds)
        )

    def add_predictions_to_dataframe(self, result: AnomalyDetectionResult) -> pd.DataFrame:
        out = self._dataframe.copy()
        out["anomaly_flag"] = result.predictions
        out["anomaly_score"] = result.anomaly_scores
        out["is_anomaly"] = result.predictions == -1
        return out

    def generate_report(self, result: AnomalyDetectionResult) -> str:
        return f"Total Records Processed: {result.anomaly_count + result.normal_count}\\nAnomalies Detected: {result.anomaly_count}\\nAnomaly Ratio: {result.anomaly_ratio:.2%}"
""".strip()

# 6. generate_mock_data.py
files["generate_mock_data.py"] = """
import random
import logging
from datetime import datetime, timedelta
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")

INSTRUMENTS = ["INST-A01", "INST-B02", "INST-C03", "INST-D04"]
BOUNDS = {"TEMP": (15.0, 85.0), "PRESS": (0.5, 5.0), "FLOW": (0.1, 2.5)}

def generate_logs(output_path: Path, lines: int = 2000):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base_time = datetime.now()
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# PharmaTrack AI - Test Logs\\n")
        for i in range(1, lines + 1):
            ts = (base_time + timedelta(seconds=i*30)).strftime("%Y-%m-%d %H:%M:%S")
            inst = random.choice(INSTRUMENTS)
            param = random.choice(list(BOUNDS.keys()))
            prob = random.random()
            
            if prob < 0.75: # Nominal
                val = round(random.uniform(BOUNDS[param][0], BOUNDS[param][1]), 2)
                line = f"{ts} | {inst} | {param} | {val} | OK\\n"
            elif prob < 0.85: # Malformed Parse Failures
                line = f"{ts} Critical Failure on {inst} without pipe splitting\\n"
            elif prob < 0.95: # Validation Bounds Breach
                val = round(BOUNDS[param][1] + random.uniform(10, 100), 2)
                line = f"{ts} | {inst} | {param} | {val} | CRITICAL\\n"
            else: # Structural Outliers
                val = round(BOUNDS[param][0] + 0.1, 2)
                line = f"{ts} | {inst} | {param} | {val} | CRITICAL\\n"
            f.write(line)
            
if __name__ == "__main__":
    generate_logs(Path("data/raw/instrument_logs.txt"))
""".strip()

# 7. main.py
files["main.py"] = """
import sys
import json
import logging
from pathlib import Path
from src.parser import LogParser
from src.validator import LogValidator
from src.anomaly_detector import AnomalyDetector

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")
    logger = logging.getLogger("PharmaTrackPipeline")
    
    input_file = Path("data/raw/instrument_logs.txt")
    val_dir = Path("data/validated")
    quar_dir = Path("data/quarantine_logs")
    
    if not input_file.exists():
        logger.error("Input logs missing. Please run generate_mock_data.py first.")
        sys.exit(1)
        
    logger.info("Starting Stage 1: Parsing Data Logs...")
    parser = LogParser()
    parsed_entries = parser.parse_file_to_list(input_file)
    
    logger.info("Starting Stage 2: Structural Verification & Constraints Enforcement...")
    validator = LogValidator(quarantine_dir=quar_dir)
    parsed_dicts = [parser.to_dict(e) for e in parsed_entries]
    validated_records = validator.validate_batch(parsed_dicts)
    
    if not validated_records:
        logger.error("Zero records passed schema bounds. Terminating flow.")
        sys.exit(1)
        
    logger.info("Starting Stage 3: Outlier Machine Learning Detection...")
    detector = AnomalyDetector(contamination=0.05)
    clean_dicts = [r.to_dict() for r in validated_records]
    detector.fit(clean_dicts)
    results = detector.detect_anomalies()
    
    out_df = detector.add_predictions_to_dataframe(results)
    out_df.to_csv(val_dir / "anomaly_results.csv", index=False)
    
    report = detector.generate_report(results)
    print("\\n" + "="*40 + "\\n" + report + "\\n" + "="*40)
    
if __name__ == "__main__":
    main()
""".strip()

# Step 3: Populate the Repository files
print("Populating modular components and machine learning scripts...")
for filepath, content in files.items():
    target_path = base_dir / filepath
    target_path.parent.mkdir(parents=True, exist_ok=True)
    with open(target_path, "w", encoding="utf-8") as f:
        f.write(content)

print("\\n" + "="*50)
print("SUCCESS: PharmaTrack AI Enterprise Layout Created Successfully!")
print("="*50)
print("Next Steps:")
print("1. cd PharmaTrack_AI")
print("2. pip install -r requirements.txt")
print("3. python generate_mock_data.py")
print("4. python main.py")
print("="*50)
